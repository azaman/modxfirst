--------------------
Theme.Bootstrap
--------------------
Author: Vasiliy Naumkin <bezumkin@yandex.ru>
--------------------
Requirements:
1. getResources
2. Wayfinder
3. getPage
4. BreadCrumb
--------------------

A basic theme for MODx Revolution based on Twitter Bootstrap (http://twitter.github.com/bootstrap/) + Bootswatch collection of 11 extra bootstrap templates (http://bootswatch.com).

You can change your default template: just add the name of the folder where others template are, for example: 
instead of default bootstrap template:
<link href="[[++assets_url]]components/themebootstrap/css/bootstrap.min.css" rel="stylesheet">

use cerulean template:
<link href="[[++assets_url]]components/themebootstrap/css/cerulean/bootstrap.min.css" rel="stylesheet">

--------------------
Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/bezumkin/Theme.Bootstrap/issues